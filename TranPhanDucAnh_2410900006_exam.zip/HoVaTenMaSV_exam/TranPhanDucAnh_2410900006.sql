-- ============================================================
-- TranPhanDucAnh_2410900006.sql
-- Sinh viên: Trần Phan Đức Anh
-- MSSV: 2410900006
-- SQL Server
-- ============================================================

IF DB_ID(N'HvtStudentDb') IS NULL
BEGIN
    CREATE DATABASE HvtStudentDb;
END
GO

USE HvtStudentDb;
GO

IF OBJECT_ID(N'dbo.HvtStudent', N'U') IS NOT NULL
BEGIN
    DROP TABLE dbo.HvtStudent;
END
GO

CREATE TABLE dbo.HvtStudent
(
    Id INT IDENTITY(1,1) NOT NULL,
    HvtName NVARCHAR(100) NOT NULL,
    HvtGender NVARCHAR(10) NOT NULL,
    HvtBirthDay DATE NOT NULL,
    HvtEmail VARCHAR(150) NOT NULL,
    HvtPhone VARCHAR(20) NULL,
    HvtActive BIT NOT NULL CONSTRAINT DF_HvtStudent_HvtActive DEFAULT (1),

    CONSTRAINT PK_HvtStudent PRIMARY KEY (Id),
    CONSTRAINT CK_HvtStudent_HvtGender CHECK (HvtGender IN (N'Nam', N'Nữ', N'Khác')),
    CONSTRAINT UQ_HvtStudent_HvtEmail UNIQUE (HvtEmail)
);
GO

-- Dữ liệu mẫu
INSERT INTO dbo.HvtStudent
    (HvtName, HvtGender, HvtBirthDay, HvtEmail, HvtPhone, HvtActive)
VALUES
    (N'Trần Phan Đức Anh', N'Nam', '2004-01-01',
     '241090006@student.example.edu.vn', '0900000006', 1),
    (N'Nguyễn Văn An', N'Nam', '2004-05-12',
     'nguyenvanan@example.com', '0912345678', 1),
    (N'Lê Thị Bình', N'Nữ', '2004-08-20',
     'lethibinh@example.com', '0987654321', 1);
GO

SELECT * FROM dbo.HvtStudent;
GO
