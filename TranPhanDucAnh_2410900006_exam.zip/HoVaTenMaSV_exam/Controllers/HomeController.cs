using HoVaTenMaSV_exam.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace HoVaTenMaSV_exam.Controllers;

public class HomeController : Controller
{
    public IActionResult HvtAbout()
    {
        return View();
    }

    public IActionResult Index()
    {
        return RedirectToAction(nameof(HvtAbout));
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel
        {
            RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier
        });
    }
}
