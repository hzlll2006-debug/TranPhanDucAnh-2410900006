using HoVaTenMaSV_exam.Data;
using HoVaTenMaSV_exam.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HoVaTenMaSV_exam.Controllers;

public class HvtStudentsController : Controller
{
    private readonly HvtStudentDbContext _context;

    public HvtStudentsController(HvtStudentDbContext context)
    {
        _context = context;
    }

    // GET: HvtStudents
    public async Task<IActionResult> Index()
    {
        return View(await _context.HvtStudent
            .OrderBy(s => s.Id)
            .ToListAsync());
    }

    // GET: HvtStudents/Details/5
    public async Task<IActionResult> Details(int? id)
    {
        if (id == null)
            return NotFound();

        var student = await _context.HvtStudent
            .FirstOrDefaultAsync(m => m.Id == id);

        if (student == null)
            return NotFound();

        return View(student);
    }

    // GET: HvtStudents/Create
    public IActionResult Create()
    {
        return View();
    }

    // POST: HvtStudents/Create
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create([Bind("Id,HvtName,HvtGender,HvtBirthDay,HvtEmail,HvtPhone,HvtActive")] HvtStudent student)
    {
        if (await _context.HvtStudent.AnyAsync(s => s.HvtEmail == student.HvtEmail))
        {
            ModelState.AddModelError("HvtEmail", "Email đã tồn tại.");
        }

        if (!ModelState.IsValid)
            return View(student);

        _context.Add(student);
        await _context.SaveChangesAsync();

        TempData["SuccessMessage"] = "Thêm sinh viên thành công.";
        return RedirectToAction(nameof(Index));
    }

    // GET: HvtStudents/Edit/5
    public async Task<IActionResult> Edit(int? id)
    {
        if (id == null)
            return NotFound();

        var student = await _context.HvtStudent.FindAsync(id);

        if (student == null)
            return NotFound();

        return View(student);
    }

    // POST: HvtStudents/Edit/5
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, [Bind("Id,HvtName,HvtGender,HvtBirthDay,HvtEmail,HvtPhone,HvtActive")] HvtStudent student)
    {
        if (id != student.Id)
            return NotFound();

        if (await _context.HvtStudent.AnyAsync(s =>
            s.HvtEmail == student.HvtEmail && s.Id != student.Id))
        {
            ModelState.AddModelError("HvtEmail", "Email đã tồn tại.");
        }

        if (!ModelState.IsValid)
            return View(student);

        try
        {
            _context.Update(student);
            await _context.SaveChangesAsync();
            TempData["SuccessMessage"] = "Cập nhật sinh viên thành công.";
        }
        catch (DbUpdateConcurrencyException)
        {
            if (!HvtStudentExists(student.Id))
                return NotFound();

            throw;
        }

        return RedirectToAction(nameof(Index));
    }

    // GET: HvtStudents/Delete/5
    public async Task<IActionResult> Delete(int? id)
    {
        if (id == null)
            return NotFound();

        var student = await _context.HvtStudent
            .FirstOrDefaultAsync(m => m.Id == id);

        if (student == null)
            return NotFound();

        return View(student);
    }

    // POST: HvtStudents/Delete/5
    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var student = await _context.HvtStudent.FindAsync(id);

        if (student != null)
        {
            _context.HvtStudent.Remove(student);
            await _context.SaveChangesAsync();
            TempData["SuccessMessage"] = "Xóa sinh viên thành công.";
        }

        return RedirectToAction(nameof(Index));
    }

    private bool HvtStudentExists(int id)
    {
        return _context.HvtStudent.Any(e => e.Id == id);
    }
}
