using HoVaTenMaSV_exam.Models;
using Microsoft.EntityFrameworkCore;

namespace HoVaTenMaSV_exam.Data;

public class HvtStudentDbContext : DbContext
{
    public HvtStudentDbContext(DbContextOptions<HvtStudentDbContext> options)
        : base(options)
    {
    }

    public DbSet<HvtStudent> HvtStudent { get; set; } = null!;

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<HvtStudent>(entity =>
        {
            entity.ToTable("HvtStudent");

            entity.HasKey(e => e.Id);

            entity.Property(e => e.HvtName)
                .HasMaxLength(100)
                .IsRequired();

            entity.Property(e => e.HvtGender)
                .HasMaxLength(10)
                .IsRequired();

            entity.Property(e => e.HvtBirthDay)
                .HasColumnType("date")
                .IsRequired();

            entity.Property(e => e.HvtEmail)
                .HasMaxLength(150)
                .IsRequired();

            entity.Property(e => e.HvtPhone)
                .HasMaxLength(20);

            entity.Property(e => e.HvtActive)
                .HasDefaultValue(true);

            entity.HasIndex(e => e.HvtEmail)
                .IsUnique();
        });
    }
}
