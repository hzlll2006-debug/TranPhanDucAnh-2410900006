using System.ComponentModel.DataAnnotations;

namespace HoVaTenMaSV_exam.Models;

public class HvtStudent
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Vui lòng nhập họ và tên.")]
    [Display(Name = "Họ và tên")]
    [StringLength(100)]
    public string HvtName { get; set; } = string.Empty;

    [Required(ErrorMessage = "Vui lòng chọn giới tính.")]
    [Display(Name = "Giới tính")]
    public string HvtGender { get; set; } = string.Empty;

    [Required(ErrorMessage = "Vui lòng nhập ngày sinh.")]
    [Display(Name = "Ngày sinh")]
    [DataType(DataType.Date)]
    public DateTime HvtBirthDay { get; set; }

    [Required(ErrorMessage = "Vui lòng nhập email.")]
    [EmailAddress(ErrorMessage = "Email không hợp lệ.")]
    [Display(Name = "Email")]
    [StringLength(150)]
    public string HvtEmail { get; set; } = string.Empty;

    [Phone(ErrorMessage = "Số điện thoại không hợp lệ.")]
    [Display(Name = "Số điện thoại")]
    [StringLength(20)]
    public string? HvtPhone { get; set; }

    [Display(Name = "Trạng thái")]
    public bool HvtActive { get; set; } = true;
}
