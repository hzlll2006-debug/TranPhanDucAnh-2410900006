# HoVaTenMaSV_exam

Sinh viên: Trần Phan Đức Anh
Mã sinh viên: 241090006

Công nghệ:
- ASP.NET Core MVC
- Entity Framework Core
- SQL Server
- Bootstrap 5

## 1. Tạo database
Mở SQL Server Management Studio và chạy file:
`HvtStudent_241090006_Db.sql`

## 2. Cấu hình connection string
Mở `appsettings.json` và sửa `Server=...` nếu SQL Server của bạn dùng tên instance khác.

Mặc định:
`Server=localhost;Database=HvtStudentDb;Trusted_Connection=True;TrustServerCertificate=True;MultipleActiveResultSets=true`

## 3. Chạy project
```bash
dotnet restore
dotnet run
```

Hoặc mở file `.csproj` bằng Visual Studio 2022/2026 và nhấn Run.

## 4. Các trang
- `/Home/HvtAbout`: Thông tin sinh viên
- `/HvtStudents`: Danh sách sinh viên và CRUD
